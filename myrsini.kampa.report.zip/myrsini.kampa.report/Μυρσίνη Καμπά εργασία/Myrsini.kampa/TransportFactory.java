package org.example;

public class TransportFactory {
    public static Transport createTransport(String type, Object... params) {
        switch (type.toLowerCase()) {
            case "truck":
                return new Truck(
                        (String) params[0],
                        (String) params[1],
                        (double) params[2],
                        (double) params[3]
                );
            case "ship":
                return new Ship(
                        (String) params[0],
                        (String) params[1],
                        (double) params[2],
                        (double) params[3],
                        (boolean) params[4]
                );
            default:
                throw new IllegalArgumentException("Άγνωστος τύπος μεταφοράς: " + type);
        }
    }
}
