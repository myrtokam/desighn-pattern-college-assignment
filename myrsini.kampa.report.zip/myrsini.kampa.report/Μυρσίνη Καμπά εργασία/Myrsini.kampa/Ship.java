package org.example;

public class Ship implements Transport {
    private String shipName;
    private String cargoType;
    private double maxLoadWeight;
    private double currentLoad;
    private double costPerNauticalMile;
    private boolean international;
    private String status;

    public Ship(String shipName, String cargoType, double maxLoadWeight, double costPerNauticalMile, boolean international) {
        this.shipName = shipName;
        this.cargoType = cargoType;
        this.maxLoadWeight = maxLoadWeight;
        this.costPerNauticalMile = costPerNauticalMile;
        this.international = international;
        this.currentLoad = 0;
        this.status = "Ready for loading";
    }

    @Override
    public boolean loadCargo(double weight) {
        if (currentLoad + weight > maxLoadWeight) {
            System.out.println("Δεν υπάρχει αρκετή χωρητικότητα.");
            return false;
        }
        currentLoad += weight;
        updateStatus("Loaded");
        return true;
    }

    @Override
    public void unloadCargo() {
        currentLoad = 0;
        updateStatus("Unloaded");
    }

    @Override
    public void deliverCargo() {
        System.out.println("Το φορτίο παραδόθηκε.");
        unloadCargo();
    }

    @Override
    public void updateStatus(String status) {
        this.status = status;
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public double calculateCost(double distance) {
        return distance * costPerNauticalMile;
    }

    @Override
    public void displayInfo() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "Ship{" +
                "shipName='" + shipName + '\'' +
                ", cargoType='" + cargoType + '\'' +
                ", maxLoadWeight=" + maxLoadWeight +
                ", currentLoad=" + currentLoad +
                ", costPerNauticalMile=" + costPerNauticalMile +
                ", international=" + international +
                ", status='" + status + '\'' +
                '}';
    }
}
