package org.example;

import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Καλώς ήρθατε στην εφαρμογή διαχείρισης μεταφορών!");
        Transport transport = initializeTransport();

        if (transport == null) {
            System.out.println("Λανθασμένη επιλογή. Έξοδος από την εφαρμογή.");
            return;
        }

        manageTransport(transport);
        scanner.close();
    }

    private static Transport initializeTransport() {
        System.out.println("Επιλέξτε τύπο μεταφοράς:");
        System.out.println("1. Φορτηγό");
        System.out.println("2. Πλοίο");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                return createTruck();
            case 2:
                return createShip();
            default:
                return null;
        }
    }

    private static Transport createTruck() {
        System.out.println("Εισάγετε τον αριθμό πινακίδας του φορτηγού:");
        String plateNumber = scanner.nextLine();

        System.out.println("Εισάγετε τον τύπο φορτίου:");
        String cargoType = scanner.nextLine();

        System.out.println("Εισάγετε τη μέγιστη χωρητικότητα (κιλά):");
        double maxCapacity = scanner.nextDouble();

        System.out.println("Εισάγετε το κόστος ανά χιλιόμετρο:");
        double costPerKm = scanner.nextDouble();

        return TransportFactory.createTransport("truck", plateNumber, cargoType, maxCapacity, costPerKm);
    }

    private static Transport createShip() {
        System.out.println("Εισάγετε το όνομα του πλοίου:");
        String shipName = scanner.nextLine();

        System.out.println("Εισάγετε τον τύπο φορτίου:");
        String cargoType = scanner.nextLine();

        System.out.println("Εισάγετε το μέγιστο βάρος φόρτωσης (κιλά):");
        double maxLoadWeight = scanner.nextDouble();

        System.out.println("Εισάγετε το κόστος ανά ναυτικό μίλι:");
        double costPerNauticalMile = scanner.nextDouble();

        System.out.println("Υποστηρίζει το πλοίο διεθνείς μεταφορές; (true/false):");
        boolean international = scanner.nextBoolean();

        return TransportFactory.createTransport("ship", shipName, cargoType, maxLoadWeight, costPerNauticalMile, international);
    }

    private static void manageTransport(Transport transport) {
        System.out.println("Εισάγετε το βάρος του φορτίου (κιλά):");
        double cargoWeight = scanner.nextDouble();

        if (transport.loadCargo(cargoWeight)) {
            System.out.println("Εισάγετε την απόσταση μεταφοράς:");
            double distance = scanner.nextDouble();

            double cost = transport.calculateCost(distance);
            System.out.println("Το κόστος της αποστολής είναι: " + cost + " €");

            transport.deliverCargo();
            System.out.println("Το φορτίο παραδόθηκε.");
        } else {
            System.out.println("Η αποστολή δεν μπορεί να ξεκινήσει λόγω υπέρβασης χωρητικότητας.");
        }

        System.out.println("Τρέχουσα κατάσταση μεταφοράς: " + transport.getStatus());
    }
}