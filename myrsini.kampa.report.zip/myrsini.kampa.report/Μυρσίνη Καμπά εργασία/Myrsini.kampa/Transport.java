package org.example;

public interface Transport {
    boolean loadCargo(double weight);
    void unloadCargo();
    void deliverCargo();
    void updateStatus(String status);
    String getStatus();
    double calculateCost(double distance);
    void displayInfo();
}