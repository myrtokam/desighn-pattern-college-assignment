package org.example;

public class Truck implements Transport {
    private String plateNumber;
    private String cargoType;
    private double maxCapacity;
    private double currentLoad;
    private double costPerKm;
    private String status;

    public Truck(String plateNumber, String cargoType, double maxCapacity, double costPerKm) {
        this.plateNumber = plateNumber;
        this.cargoType = cargoType;
        this.maxCapacity = maxCapacity;
        this.costPerKm = costPerKm;
        this.currentLoad = 0;
        this.status = "Ready for loading";
    }

    @Override
    public boolean loadCargo(double weight) {
        if (currentLoad + weight > maxCapacity) {
            System.out.println("Δεν υπάρχει αρκετή χωρητικότητα.");
            return false;
        }
        currentLoad += weight;
        updateStatus("Loaded");
        return true;
    }

    @Override
    public void unloadCargo() {
        currentLoad = 0;
        updateStatus("Unloaded");
    }

    @Override
    public void deliverCargo() {
        System.out.println("Το φορτίο παραδόθηκε.");
        unloadCargo();
    }

    @Override
    public void updateStatus(String status) {
        this.status = status;
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public double calculateCost(double distance) {
        return distance * costPerKm;
    }

    @Override
    public void displayInfo() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "Truck{" +
                "plateNumber='" + plateNumber + '\'' +
                ", cargoType='" + cargoType + '\'' +
                ", maxCapacity=" + maxCapacity +
                ", currentLoad=" + currentLoad +
                ", costPerKm=" + costPerKm +
                ", status='" + status + '\'' +
                '}';
    }
}
